<%@ include file="_encabezado.jspf" %>
<div class="ventana">
    <h1>MENÚ PRINCIPAL</h1>
    <div class="menu">
        <a href="${pageContext.request.contextPath}/preguntas"><span class="ico">&#10067;</span><b>Preguntas</b>
            <span>CU020 Gestionar Preguntas · CU021 Dar de alta Pregunta</span></a>
        <a href="${pageContext.request.contextPath}/evaluar"><span class="ico">&#128101;</span><b>Evaluar Candidatos</b>
            <span>CU025 Evaluar a Candidatos</span></a>
        <a href="${pageContext.request.contextPath}/orden-merito"><span class="ico">&#127942;</span><b>Orden de Méritos</b>
            <span>CU028 Emitir Orden de Mérito</span></a>
        <a class="deshabilitado"><span class="ico">&#128188;</span><b>Puestos</b><span>CU008 (fuera del alcance de las etapas 7 y 8)</span></a>
        <a class="deshabilitado"><span class="ico">&#127919;</span><b>Competencias</b><span>CU012 (fuera del alcance)</span></a>
        <a class="deshabilitado"><span class="ico">&#129513;</span><b>Factores</b><span>CU016 (fuera del alcance)</span></a>
        <a class="deshabilitado"><span class="ico">&#9745;</span><b>Opciones de Respuesta</b><span>CU024 (fuera del alcance)</span></a>
        <a class="deshabilitado"><span class="ico">&#128229;</span><b>Importar Candidatos</b><span>CU006 (fuera del alcance)</span></a>
        <a class="deshabilitado"><span class="ico">&#128202;</span><b>Reporte Comparativo</b><span>CU027 (fuera del alcance)</span></a>
    </div>
</div>
<%@ include file="_pie.jspf" %>
